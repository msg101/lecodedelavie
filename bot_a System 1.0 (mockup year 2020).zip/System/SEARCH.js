/*
 *     this is UX, it should be a later add to bot_a
 *
 * 
 * 
 * 
 * 
 * 
 * 
 */