/*
 *
 * ML ai is based on logic assignment technologies
 * MLai.certainVariable = "String1";
 * MLai.certainVariableLogics = new Boolean(true);
 * 
 * 
 * function activeNmorph(){
 *
 *       do while{
 * 
 * 
 * 
 * 
 */
class MLai{
        constructor(){
                this.intelligence = "logic assignment technologies";
                this.whoareyouClause = "who are you?";
                this.whoareyouClauseLogics = new Boolean(true);
        }
}

MLai1 = new MLai();


            
        












