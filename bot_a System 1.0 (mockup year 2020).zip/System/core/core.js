




 //boot to System 
 //would have to make bot_a self-aware
 //i, you, self, dangers, damages

 // would need PSeudo codes to how to do self-aware unit
 //then it call System Object System.Calls.core2System();
 
 class Core{
   constructor(){
      this.model = "A100";
      this.serial = "MLaiA100";
      this.mfg = "Jupiterjst";
   
   }
         
         
}

 Core1 = new Core();
 System1.bootRqst();
 
//Core.prototype.attributesExample = "yes";
 
/*Core.prototype.methodExample = function (){
//}
 */

