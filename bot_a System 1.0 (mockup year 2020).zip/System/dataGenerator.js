/*
 *
 *    Clause Object can be used as Array.  So Clause.article can be access as Clause[0]
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */