/*
 *
 *
 *   with Intelligence and ML, when it's too many it become a CPUAPU
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */